/* eslint-disable no-useless-escape */
import React, { useState, useEffect, useRef } from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './Form.scss';

const Form = () => {
  const [inputName, setInputName] = useState('');
  const [inputEmail, setInputEmail] = useState('');
  const [inputPhone, setInputPhone] = useState('');
  const [isCheckboxChecked, setIsCheckboxChecked] = useState(false);
  const [isRadioChecked, setIsRadioChecked] = useState(false);
  const [isError, setIsError] = useState(true);

  // const [values, setValues] = useState({
  //   inputName: '',
  //   inputEmail: '',
  //   inputPhone: '',
  // });

  const input = useRef<HTMLInputElement>(null);

  const submittedFormNotify = () => toast.success('🦄 Thanks for filling out our form!', {
    position: 'top-center',
    autoClose: 3000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
  });

  useEffect(() => {
    input.current?.focus();
  }, []);

  const inputsData = [
    {
      className: 'input input--name',
      type: 'text',
      value: inputName,
      ref: input,
      placeholder: 'Fullname',
      onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
        setInputName(e.target.value);
      },
      validation: inputName.length < 4,
      errorMsg: 'Username is not valid',
      key: 1,
    },
    {
      className: 'input input--email',
      type: 'email',
      value: inputEmail,
      placeholder: 'E-mail',
      onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
        setInputEmail(e.target.value);
      },
      validation: !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(
        inputEmail,
      ),
      errorMsg: 'E-mail is not valid',
      key: 2,
    },
    {
      className: 'input input--phone',
      type: 'tel',
      value: inputPhone,
      placeholder: 'Phone number',
      onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
        setInputPhone(e.target.value);
      },
      validation: !/\(?([0-9]{3})\)?([ .-]?)([0-9]{3})\2([0-9]{2})/.test(
        inputPhone,
      ),
      errorMsg: 'Phone number is not valid',
      key: 3,
    },
    {
      className: 'radio',
      labelClassName: 'label label--male',
      type: 'radio',
      label: 'Male',
      id: 'Male',
      name: 'radio',
      onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
        setIsRadioChecked(e.target.checked);
      },
      validation: !isRadioChecked,
      key: 4,
    },
    {
      className: 'radio',
      labelClassName: 'label label--female',
      type: 'radio',
      label: 'Female',
      id: 'Female',
      name: 'radio',
      onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
        setIsRadioChecked(e.target.checked);
      },
      validation: !isRadioChecked,
      errorMsg: 'Select your gender',
      key: 5,
    },
    {
      className: 'checkbox',
      labelClassName: 'label label--checkbox',
      type: 'checkbox',
      label: 'I am not a robot',
      id: 'I am not a robot',
      checked: isCheckboxChecked,
      onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
        setIsCheckboxChecked(e.target.checked);
      },
      validation: !isCheckboxChecked,
      errorMsg: 'Are you a robot?',
      key: 6,
    },
  ];

  const handleSubmit = (e: React.ChangeEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsError(false);
    let inputErrors = false;

    inputsData.map((it) => {
      if (it.validation) {
        inputErrors = true;
      }
      return inputErrors;
    });

    if (!inputErrors) {
      submittedFormNotify();
    }
  };

  return (
    <div className="form__section">
      <ToastContainer
        position="top-center"
        autoClose={3000}
        hideProgressBar
        newestOnTop={false}
        closeOnClick
        rtl={false}
        theme="dark"
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />

      <form className="form" onSubmit={handleSubmit}>
        <h1 className="form__title">React Form</h1>
        {inputsData.map(
          ({
            className,
            labelClassName,
            ref,
            type,
            placeholder,
            label,
            name,
            id,
            value,
            onChange,
            checked,
            validation,
            errorMsg,
            key,
          }) => (
            <label
              className={labelClassName}
              htmlFor={label}
              key={key}
            >
              <input
                ref={ref}
                style={{
                  outline:
                    validation && isError === false
                      ? '2px solid #ee4c4c'
                      : '',
                }}
                className={className}
                type={type}
                placeholder={placeholder}
                checked={checked}
                value={value}
                name={name}
                id={id}
                onChange={onChange}
              />
              {label}
              {validation && !isError && (
                <span className="error__message">{errorMsg}</span>
              )}
            </label>
          ),
        )}

        <button
          className="submit__button"
          type="submit"
        >
          Submit
        </button>
      </form>
    </div>
  );
};

export default Form;
