import './App.scss';
import Form from './components/Form/Form';

const App = () => (
  <div className="container">
    <Form />
  </div>
);

export default App;
